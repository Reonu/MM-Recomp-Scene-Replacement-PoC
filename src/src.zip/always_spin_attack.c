#include "modding.h"
#include "global.h"
#include "recomputils.h"

#include "mm_test_scene.h"

#define REPLACED_SCENE SCENE_CLOCKTOWER
//#define REPLACED_SCENE SCENE_INSIDETOWER

// Populate this when you add more rooms
void* custom_scene_rooms[] = {
    mm_test_room_0_header00,
};

// Dummy symbols to let the rooms compile
u8 _mm_test_room_0SegmentRomStart[1];
u8 _mm_test_room_0SegmentRomEnd[1];

RECOMP_HOOK("Play_InitScene") void on_init_scene(PlayState* play, s32 spawn) {
    recomp_printf("Spawning into scene %d (spawn %d)\n", play->sceneId, spawn);

    if (play->sceneId == REPLACED_SCENE) {
        // Replace the sceneSegment with our custom one. No need to free the original memory since it's part of an arena
        // and will get freed automatically when resetting between scenes.
        play->sceneSegment = mm_test_scene_header00;
    }
}

RECOMP_HOOK("Room_RequestNewRoom") void on_room_request(PlayState* play, RoomContext* roomCtx, s32 index) {
    if (play->sceneId == REPLACED_SCENE && roomCtx->status == 0) {
        roomCtx->prevRoom = roomCtx->curRoom;
        roomCtx->curRoom.num = index;
        roomCtx->curRoom.segment = NULL;
        roomCtx->status = 1;
        roomCtx->roomRequestAddr = custom_scene_rooms[index];
        roomCtx->activeBufPage ^= 1;

        // Record that a room load request has to be sent after the request function returns.
        osCreateMesgQueue(&roomCtx->loadQueue, roomCtx->loadMsg, ARRAY_COUNT(roomCtx->loadMsg));
        osSendMesg(&roomCtx->loadQueue, NULL, OS_MESG_NOBLOCK);
    }
}